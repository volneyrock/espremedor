# -*- coding: iso-8859-1 -*-
import sqlite3
import ttk
from Tkinter import *
import tkMessageBox
  
#Criar conex�o e cursor
con = sqlite3.connect('deliverydb.db')
cur = con.cursor()
#Criar tabela clientes
cur.execute('''CREATE TABLE IF NOT EXISTS clientes (
            nome VARCHAR,
            telefone VARCHAR PRIMARY KEY,
            endereco VARCHAR,
            comp VARCHAR)''')
#Criar tabela produtos
cur.execute('''CREATE TABLE IF NOT EXISTS produtos(
            referencia INT PRIMARY KEY NOT NULL,
            descricao varchar(100) NOT NULL,
            preco dec NOT NULL)''')
# Criar tabela pedido
cur.execute('''CREATE TABLE IF NOT EXISTS pedido(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            referencia INT NOT NULL,
            descricao VARCHAR(100) NOT NULL,
            quantidade DEC NOT NULL,
            preco DEC NOT NULL,
            total DEC NOT NULL)''')
#Limpa a tabela pedido
cur.execute("DELETE FROM pedido WHERE 1")
            
class main:
    def __init__(self,master):
#-------------------------------------------Abas--------------------------------------------------------------#
        self.abas = ttk.Notebook(master)
        self.abas.place(relx=0.0,rely=0.0,relheight=1.0,relwidth=1.0)
        self.abas.configure(width=800)
        self.abas.configure(takefocus="")
        self.abas_pg0 = ttk.Frame(self.abas)
        self.abas.add(self.abas_pg0, padding=3)
        self.abas.tab(0, text="Clientes",underline="-1")
        self.abas_pg1 = ttk.Frame(self.abas)
        self.abas.add(self.abas_pg1, padding=3)
        self.abas.tab(1, text="Pedidos",underline="-1",)
#-----------------------------------------Aba Clientes--------------------------------------------------------#
        self.frame1 = Frame(self.abas_pg0,bg='sky blue')
        self.frame1.configure(relief=GROOVE)
        self.frame1.configure(borderwidth="2")
        self.frame1.place(relx=0.0,rely=0.0,relheight=1.0,relwidth=0.51)
        Label(self.frame1,text='CADASTRO',font=('Ariel','30'),bg='sky blue').place(relx=0.30,rely=0.01)
        Label(self.frame1,text='Nome',font=('Ariel','15'),bg='sky blue').place(relx=0.02,rely=0.12)
        self.nome=Entry(self.frame1,font=('Ariel','20'))
        self.nome.place(relx=0.02,rely=0.16)
        Label(self.frame1,text=u'Endere�o',font=('Ariel','15'),bg='sky blue').place(relx=0.02,rely=0.21)
        self.endereco = Entry(self.frame1,font=('Ariel','20'))
        self.endereco.place(relx=0.02,rely=0.25,relwidth=0.94)
        Label(self.frame1,text='Telefone',font=('Ariel','15'),bg='sky blue').place(relx=0.02,rely=0.31)
        self.fone = Entry(self.frame1,font=('Ariel','20'))
        self.fone.place(relx=0.02,rely=0.36,width=200)
        Label(self.frame1,text='Complemento',font=('Ariel','15'),bg='sky blue').place(relx=0.02,rely=0.50)
        self.comp = Text(self.frame1,font=('Ariel','20'))
        self.comp.place(relx=0.02,rely=0.55,relwidth=0.94,relheight=0.43)
        self.botaocadastra = Button(self.frame1,text='Cadastrar',font=('Ariel','20'),
                                    fg='green',command=self.cadastraclientes)
        self.botaocadastra.place(relx=0.62,rely=0.33,relwidth=0.31)
        self.botaocancela = Button(self.frame1,text='Novo/Cancelar',font=('Ariel','20'),
                                   fg='red',command=self.limpaclientes)
        self.botaocancela.place(relx=0.62,rely=0.44,relwidth=0.31)
        
        self.frame2 = Frame(self.abas_pg0,bg='sky blue')
        self.frame2.configure(relief=GROOVE)
        self.frame2.configure(borderwidth="2")
        self.frame2.place(relx=0.51,rely=0.0,relheight=0.31,relwidth=0.49)
        Label(self.frame2,text='CONSULTA',font=('Ariel','30'),bg='sky blue').place(relx=0.29,rely=0.05)
        self.fonec=Entry(self.frame2,font=('Ariel','20'))
        self.fonec.bind("<Return>",self.mostraclientes_a)
        self.fonec.place(relx=0.22,rely=0.42)
        self.botaook = Button(self.frame2, text='OK',font=('Ariel','25'),
                              fg='green',command=self.mostraclientes)
        self.botaook.place(relx=0.38,rely=0.65)

        self.frame3 = Frame(self.abas_pg0)
        self.frame3.configure(relief=GROOVE)
        self.frame3.configure(borderwidth="2")
        self.frame3.place(relx=0.51,rely=0.31,relheight=0.69,relwidth=0.49)
        self.mostra1 = Text(self.frame3,bg='azure',font=('Courier','20','bold'),fg='blue')
        self.mostra1.place(relx=0.00,rely=0.0,relheight=1.0,relwidth=1.0)
#----------------------------------Aba Pedidos(Cadastro)-----------------------------------------------------#
        self.frame4 = Frame(self.abas_pg1,bg='sky blue')
        self.frame4.place(relx=0.0,rely=0.0,relheight=1.0,relwidth=0.48)
        Label(self.frame4,text='CADASTRO',font=('Ariel','30'),bg='sky blue').place(relx=0.25,rely=0.01)
        Label(self.frame4, text=u"Refer�ncia",font=('Ariel','15'),bg='sky blue').place(relx=-0.0,rely=0.10)
        self.referencia_c = Entry(self.frame4, width=10, font=('Ariel','20'))
        self.referencia_c.place(relx=0.0,rely=0.15)
        Label(self.frame4, text=u"Descri��o",font=('Ariel','15'),bg='sky blue').place(relx=0.0,rely=0.25)
        self.descricao_c = Entry(self.frame4,font=('Ariel','20'))
        self.descricao_c.place(relx=0.0,rely=0.30,relwidth=1.0)
        Label(self.frame4, text=u"Pre�o",font=('Ariel','15'),bg='sky blue').place(relx=0.0,rely=0.40)
        self.preco_c = Entry(self.frame4,width=10,font=('Ariel','20'))
        self.preco_c.place(relx=0.0,rely=0.45)
        self.botaocadastra_produto = Button(self.frame4,text='Cadastrar',font=('Ariel','20'),
                                    fg='green',command=self.cadastraproduto)
        self.botaocadastra_produto.place(relx=0.70,rely=0.14,relwidth=0.25)
        self.botaoeditar_produto = Button(self.frame4,text='Editar',font=('Ariel','20'),
                                    fg='green',command=self.janelaedit)
        self.botaoeditar_produto.place(relx=0.70,rely=0.22,relwidth=0.25)
        self.preenchelista()
        #Pedido
        self.frame5 = Frame(self.abas_pg1,bg='sky blue')
        self.frame5.place(relx=0.49,rely=0.0,relheight=1.0,relwidth=0.52)
        Label(self.frame5,text='PEDIDO',font=('Ariel','30'),bg='sky blue').place(relx=0.35,rely=0.01)
        Label(self.frame5, text=u"Refer�ncia",font=('Ariel','15'),bg='sky blue').place(relx=-0.0,rely=0.10)
        self.referencia_p = Entry(self.frame5, width=10, font=('Ariel','20'))
        self.referencia_p.place(relx=0.0,rely=0.15)
        Label(self.frame5,text='Quantidade',font=('Ariel','15'),bg='sky blue').place(relx=0.0,rely=0.25)
        self.quantidade_p = Entry(self.frame5, width=10, font=('Ariel','20'))
        self.quantidade_p.place(relx=0.0,rely=0.30)
        Label(self.frame5,text='Adicional',font=('Ariel','15'),bg='sky blue').place(relx=0.0,rely=0.40)
        self.extra = Entry(self.frame5, width=10, font=('Ariel','20'))
        self.extra.place(relx=0.0,rely=0.45)
        self.lista = Listbox(self.frame5,font=('Courier','15'),fg='blue')
        self.lista.place(relx=0.0,rely=0.55,relheight=0.42,relwidth=1.0)
        self.botao_pedido = Button(self.frame5,text='OK',font=('Ariel','25'),fg='green',command=self.pedido)
        self.botao_pedido.place(relx=0.65,rely=0.10,relwidth=0.31)
        self.cancela_pedido = Button(self.frame5,text='Cancelar',font=('Ariel','25'),fg='red',command=self.cancelapedido)
        self.cancela_pedido.place(relx=0.65,rely=0.20,relwidth=0.31)
        Label(self.frame5, text="Total",font=('Ariel','15'),bg='sky blue').place(relx=0.70,rely=0.40)
        self.total = Entry(self.frame5, width=10, font=('Ariel','20'),fg='red')
        self.total.place(relx=0.7,rely=0.45)


          
#-----------------------------------------FUN��ES-----------------------------------------------------------#
    def cadastraclientes(self):
        nome=self.nome.get()
        telefone=self.fone.get()
        endereco=self.endereco.get()
        comp=self.comp.get(0.0,END)
        try:
            cur.execute("INSERT INTO clientes VALUES(?,?,?,?)",
                    (nome,telefone,endereco,comp))
        except:
            tkMessageBox.showinfo('Aviso!',u'Telefone j� cadastrado')  
        con.commit()
        self.fone.delete(0,END)
        

    def limpaclientes(self):
        self.nome.delete(0,END)
        self.fone.delete(0,END)
        self.endereco.delete(0,END)
        self.comp.delete(0.0,END)
        
    def mostraclientes(self):
        self.mostra1.delete(0.0,END)
        fonec = self.fonec.get()
        cur.execute("SELECT * FROM clientes WHERE telefone = '%s'" %fonec)
        consulta = cur.fetchall()
        for i in consulta:
            self.mostra1.insert(END,'''Nome:{}
End:{}
Complemento:{}'''.format(i[0],i[2],i[3]))
    def mostraclientes_a(self,event):
        self.mostraclientes()
        
    def cadastraproduto(self):
        referencia = self.referencia_c.get()
        descricao = self.descricao_c.get()
        preco = self.preco_c.get()
        try:
            cur.execute("INSERT INTO produtos VALUES(?,?,?)",(referencia,descricao,preco))
        except:
            tkMessageBox.showinfo('Aviso!',u'Refer�ncia ja cadastrada, ou inv�lida')
        con.commit()    
        self.referencia_c.delete(0,END)                                   
        self.descricao_c.delete(0,END)
        self.preco_c.delete(0,END)
        self.preenchelista()
    def preenchelista(self):
        #Cabe�alho
        self.dataCols = (u'Refer�ncia',u'Descri��o',u'Pre�o')
        self.arvore = ttk.Treeview(self.frame4,columns=self.dataCols, show='headings')
        self.arvore.place(relx=0.0,rely=0.55,relheight=0.42,relwidth=1.0)
        for c in self.dataCols:
            self.arvore.heading(c, text = c.title())
        #Limpa a lista    
        for i in self.arvore.get_children():
            tree.delete(i)
        #Consulta BD e preenche a lista    
        dados=cur.execute('SELECT * FROM produtos')
        for item in dados:
            self.arvore.insert('','end',values=item)
        self.arvore.bind('<<TreeviewSelect>>',self.itemselect)

    def itemselect(self,event):
        self.referencia_p.delete(0,END)
        item = self.arvore.selection()
        item = self.arvore.item(item,'values')
        self.referencia_p.insert(END,item[0])
#------------------------------FUN��O PEDIDO------------------------------------------------------
    def pedido(self):
        self.lista.delete(0,END)
        ref = self.referencia_p.get()
        quant = float(self.quantidade_p.get())
        cur.execute("SELECT * FROM produtos WHERE referencia = %s" %ref)
        item_p = cur.fetchone()
        descricao = item_p[1]
        preco = item_p[2]
        precof = float(preco)*quant
        extra = float(self.extra.get())
        cur.execute("INSERT INTO pedido VALUES(?,?,?,?,?,?)",
                    (None,ref,descricao,quant,preco,precof))
        con.commit()
        tb=cur.execute("SELECT * FROM pedido")
        for i in tb:
            self.lista.insert(END,u"{:.<4}{:.^25}{:.>4.2f}".format(i[3],i[2],i[5]))
        cur.execute("SELECT SUM(total)FROM pedido")
        soma = float(cur.fetchone()[0])
        total = soma+extra
        self.total.delete(0,END)
        self.total.insert(END,"R$:%.2f"%total)
        self.lista.insert(END,u'Extra' + 24* '.' + '%.2f' %extra)
#-----------------------------------Janela de edi��o de produtos------------------------------------
    def janelaedit(self):
        top = Toplevel()
        Label(top, text=u"Refer�ncia",font=('Ariel','10')).place(relx=0.0,rely=0.0)
        self.ref_edit = Entry(top,width=10, font=('Ariel','10'))
        self.ref_edit.place(relx=0.0,rely=0.1)
        Label(top, text=u"Descri��o",font=('Ariel','10')).place(relx=0.0,rely=0.2)
        self.desc_edit = Entry(top,width=10, font=('Ariel','10'))
        self.desc_edit.place(relx=0.0,rely=0.3,relwidth=0.9)
        Label(top, text=u"Pre�o",font=('Ariel','10')).place(relx=0.0,rely=0.4)
        self.preco_edit = Entry(top,width=10, font=('Ariel','10'))
        self.preco_edit.place(relx=0.0,rely=0.5)
        botao_fechar = Button(top, text="Fechar", command=top.destroy)
        botao_fechar.place(relx=0.6,rely=0.8)
        botao_altera = Button(top, text="Alterar", command=self.alteraproduto)
        botao_altera.place(relx=0.0,rely=0.8)
        #Preenche janela
        item = self.arvore.selection()
        item = self.arvore.item(item,'values')
        self.ref_edit.insert(END,item[0])
        self.desc_edit.insert(END,item[1])
        self.preco_edit.insert(END,item[2])
        top.geometry("200x220")
        top.grab_set()
        top.mainloop()
    def alteraproduto(self):
        ind = self.ref_edit.get()
        ref_novo = self.ref_edit.get()
        desc_novo = self.desc_edit.get()
        preco_novo = self.preco_edit.get()
        cur.execute('''UPDATE produtos SET referencia = ?,
                    descricao = ?,
                    preco = ?
                    WHERE referencia = ?''',
                    (ref_novo,desc_novo,preco_novo,ind))
        con.commit()
        self.preenchelista()
    def cancelapedido(self):
        cur.execute("DELETE FROM pedido WHERE 1")#Apaga pedido
        self.lista.delete(0,END) #Limpa a listbox
        self.total.delete(0,END)#Apaga campo referencia
        self.referencia_p.delete(0,END)#Apaga campo quantidade
        self.quantidade_p.delete(0,END)#Apaga campo Total do Pedido
        self.extra.delete(0,END)
                        
root = Tk()
root.title("TuxDelyvery")
root.geometry("1366x768")
main(root)
root.mainloop()
