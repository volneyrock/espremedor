# -*- coding: iso-8859-1 -*-
from Tkinter import *
import sqlite3
from autocomplete import *


#Criar conex�o e cursor
con = sqlite3.connect('deliverydb.db')
cur = con.cursor()
#Criar tabela clientes
cur.execute("""CREATE TABLE IF NOT EXISTS clientes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome VARCHAR,
            telefone VARCHAR,
            endereco VARCHAR,
            comp VARCHAR)""")
class main:
    def __init__(self,master):
        self.frame = Frame(master)
        self.frame.pack()
        entry = AutocompleteCombobox(self.frame)
        lista = ['adriana','123','bolo','cachorro',
                 'dado','escola','faca']
        #cur.execute("SELECT nome FROM clientes")
        #lista=cur.fetchall()
        entry.set_completion_list(lista)
        entry.pack()

                        
root = Tk()
root.title("Aqui vai o titulo da Janela")
root.geometry("800x600")
main(root)
root.mainloop()
